export default [
  require('/root/my-website/node_modules/infima/dist/css/default/default.css'),
  require('/root/my-website/node_modules/@docusaurus/theme-classic/lib/prism-include-languages'),
  require('/root/my-website/node_modules/@docusaurus/theme-classic/lib/nprogress'),
  require('/root/my-website/src/css/custom.css'),
];
